package soft.bean;

public class Data {

}
